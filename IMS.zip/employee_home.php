<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Employee Home </title>
    
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
      <style>
        .btn {
            margin: 20px; /* Adjust this value to increase or decrease the space between buttons */
        }
    </style>
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> IMS </div>
            <div class="col-md-10" style="text-align: right"> 
                <a href="home.php"> Home </a> 
                <a href="#" style="margin-left: 20px;"> Employee </a> 
                <a href="admin.php" style="margin-left: 20px;"> Admin </a> 
            </div>
        </div>
    </section>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 bg-light" style="height: 100vh;">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="employee_profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="signout.php">Sign Out</a>
                    </li>
                </ul>
            </div>
            <!-- Main content -->
            <div class="col-md-10 d-flex justify-content-center align-items-center" style="height: 100vh; background-image: url('bg.jpg'); background-size: cover; background-position: center;">
                <div class="text-center" style="margin-top: 150px;">
                    <a href='add_customer.php' class="btn btn-primary m-2">Add Customer</a>
                    <a href='sales_form.php' class="btn btn-default m-2">Update Sales</a>
                    <a href='BUYER.php' class="btn btn-success m-2"> Manage buys</a>
                    <button class="btn btn-danger m-2">Button 4</button>
                </div>
            </div>
        </div>
    </div>

    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
  </body>
</html>