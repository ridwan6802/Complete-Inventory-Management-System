<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Sign In </title>
    
      <!-- core CSS -->
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
  </head>
  
  <body>
    <section id = "section1">
		<div class="title"> SIGN IN </div>
		
		<form action="employee_signin_check.php" class="form_design" method="post">
			Username: <input type="text" name="username"> <br/>
			Password: <input type="password" name="password"> <br/> <br/>
			<input type="submit" value="Sign In">
		</form>
	</section>
	
	
	<section id="footer"> 
	
	</section>
    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="jquery.isotope.min.js"></script>
    <script src="wow.min.js"></script>
  </body> 
</html>