<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Add Customer </title>
    
      <!-- core CSS -->
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> IMS </div>
		</div>
	</section>
	
	<section id = "section1">
        <div class="title"> New Customer </div>
        
        <form action="insert_customer.php" class="form_design" method="post">
            Customer ID: <input type="text" name="customer_id"> <br/>
            Name: <input type="text" name="name"> <br/> 
            Address: <input type="text" name="address"> <br/>
            Email: <input type="text" name="email"> <br/>
            Phone: <input type="text" name="phone"> <br/>
            <br/>
            <input type="submit" value="ADD NEW CUSTOMER">
        </form>
    </section>
	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="jquery.isotope.min.js"></script>
    <script src="wow.min.js"></script>
  </body> 
</html>

