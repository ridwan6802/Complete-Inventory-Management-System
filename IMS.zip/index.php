<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Welcome </title>
    
      <!-- core CSS -->
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> 
      <a href="index.php"> IMS </a> </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="signin_choice.php" style="margin-left: 20px;"> Sign In </a> 
				<a href="signup_choice.php" style="margin-left: 20px;"> Sign Up </a> 
			</div>
		</div>
	</section>
	
	<section id="section1" class="button-container">
    	<div class="title" style="margin-top: 0px"> WELCOME to our IMS! </div>
	</section>
	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="jquery.isotope.min.js"></script>
    <script src="wow.min.js"></script>
  </body> 
</html>


