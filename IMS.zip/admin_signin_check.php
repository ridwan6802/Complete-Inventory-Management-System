<?php
// first of all, we need to connect to the database
require_once('DBconnect.php');
session_start();

// we need to check if the input in the form textfields are not empty
if(isset($_POST['username']) && isset($_POST['password'])){
	// write the query to check if this username and password exists in our database
	$u = $_POST['username'];
	$p = $_POST['password'];
	$sql = "SELECT * FROM admin WHERE username = '$u' AND password = '$p'";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);
	
	//check if it returns an empty set
	if(mysqli_num_rows($result) !=0 ){
		$user = mysqli_fetch_assoc($result);
		$_SESSION['user_id'] = $user['ID'];

		//echo "LET HIM ENTER";
		header("Location: admin_home.php");
		exit();
	}
	else{
		//echo "Username or Password is wrong!";
		echo "<script>alert('Username or Password is incorrect'); window.location.href = 'admin_signin.php';</script>";
	}
	
}


?>
