<?php
require('DBconnect.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: employee_signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $salary = $_POST['salary'];

    $sql = "UPDATE employee SET first_name = ?, last_name = ?, email = ?, address = ?, salary = ? WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdi", $first_name, $last_name, $email, $address, $salary, $user_id);
    if ($stmt->execute()) {
        header("Location: employee_profile.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$sql = "SELECT first_name, last_name, email, address, salary FROM employee WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($first_name, $last_name, $email, $address, $salary);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="bootstrap.min.css" rel="stylesheet"/>
    <style>
        body {
            background-image: url('bg.jpg'); /* Replace with your background image path */
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .container h1 {
            text-align: center;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        .container label, .container input {
            margin-bottom: 10px;
        }
        .container input[type="submit"] {
            align-self: center;
            padding: 10px 20px;
            background-color:rgb(76, 145, 175);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .container input[type="submit"]:hover {
            background-color:rgb(69, 120, 160);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Profile</h1>
        <form method="post" action="">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $first_name; ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $last_name; ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>" required>
            </div>
            <div class="form-group">
                <label for="salary">Salary:</label>
                <td><?php echo $salary; ?></td>
                <!-- <input type="number" class="form-control" id="salary" name="salary" value="<?php echo $salary; ?>" required> -->
            </div>
            <input type="submit" value="Save">
        </form>
    </div>
</body>
</html>