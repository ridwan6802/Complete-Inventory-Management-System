<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Admin Home </title>
    
      <!-- core CSS -->
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;">
            <a href="admin_home.php">IMS</a></div>
            <div class="col-md-10" style="text-align: right"> 
                <a href="home.php"> Home </a> 
                <a href="#" style="margin-left: 20px;"> Employee </a> 
                <a href="admin.php" style="margin-left: 20px;"> Admin </a> 
            </div>
        </div>
    </section>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="employee.php">
                                Employees
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="show_sales.php">
                                Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_profile.php">
                                Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signout.php">
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
                        

            <!-- Main content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <section id="section1">
                    <div class="title" style="margin-top:100px"> HOME PAGE </div>
                    <div class="d-flex justify-content-center align-items-center" style="height: 80vh;">
                        <div class="row w-100" style="margin-top: 100px;">
                            <div class="col-md-3 d-flex justify-content-center">
                                <a href="add_product.php" class="btn btn-primary btn-block">Add Products</a>
                            </div>
                            <div class="col-md-3 d-flex justify-content-center">
                                <a href="customer_list.php" class="btn btn-default btn-block">Customer List</a>
                            </div>
                            <div class="col-md-3 d-flex justify-content-center">
                                <a href="stock.php" class="btn btn-success btn-block">Stock</a>
                            </div>
                            <div class="col-md-3 d-flex justify-content-center">
                                <a href="branch.php" class="btn btn-danger btn-block">Branches</a>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </div>
	
    <!----- Footer ----->
    <section id="footer"> 
    
    </section>
      <script src="jquery.js"></script>
      <script src="bootstrap.min.js"></script>
      <script src="jquery.isotope.min.js"></script>
      <script src="wow.min.js"></script>
  </body> 
</html>

