<?php
require_once('DBconnect.php');

if(isset($_POST['customer_id']) && isset($_POST['name']) && isset($_POST['address']) && isset($_POST['email']) && isset($_POST['phone'])){
    $i = $_POST['customer_id'];
	$n = $_POST['name'];
	$a = $_POST['address'];
	$e = $_POST['email'];
    $p = $_POST['phone'];

	if (empty($i) || empty($n) || empty($a) || empty($e) || empty($p)) {
        echo "All fields are required.";
        exit();
    }
	
	$sql = " INSERT INTO customer VALUES('$i', '$n', '$a', '$e', '$p') ";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);
	
	//check if this insertion is happening in the database
	if(mysqli_affected_rows($conn)){
	
		echo "Inserted Successfully";
		//header("Location: admin.php");
	}
	else{
		echo "Insertion Failed";
		//header("Location: admin_signup.php");
	}
	
}

?>