<?php
// first of all, we need to connect to the database
require_once('DBconnect.php');

// we need to check if the input in the form textfields are not empty
if(isset($_POST['ID']) && isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['email']) && isset($_POST['branch_id']) && isset($_POST['username']) && isset($_POST['password'])){
	// write the query to check if this username and password exists in our database
	$i = $_POST['ID'];
	$f = $_POST['fname'];
	$l = $_POST['lname'];
	$e = $_POST['email'];
	$b = $_POST['branch_id'];
	$u = $_POST['username'];
	$p = $_POST['password'];
	
	if (empty($i) || empty($f) || empty($l) || empty($e) || empty($b) || empty($u) || empty($p)) {
        echo "All fields are required.";
        exit();
    }

	$sql = " INSERT INTO employee VALUES( '$i', '$f', '$l', '$e', '', '', '$b', '$u', '$p') ";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);
	
	//check if this insertion is happening in the database
	if(mysqli_affected_rows($conn)){
	
		//echo "Inseted Successfully";
		header("Location: employee_signin.php");
	}
	else{
		//echo "Insertion Failed";
		header("Location: employee_signup.php");
	}
	
}


?>