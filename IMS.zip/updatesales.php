<?php
// Database connection
require_once('DBconnect.php');

// Function to update sales
function updateSales($branch_id, $unit_price, $quantity_sold, $profit, $delivery_status, $employee_id) {
    global $conn;

    // Insert sale record into sales table
    $sql = "INSERT INTO sales (branch_id, unit_price, quantity_sold, profit, delivery_status, employee_id)
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ididss", $branch_id, $unit_price, $quantity_sold, $profit, $delivery_status, $employee_id);

    if ($stmt->execute()) {
        echo "Sale updated successfully.<br>";
        header("Location: BUYER.php");
    } else {
        echo "Error: " . $stmt->error;
        header("Location: employee_home.php");
    }

    $stmt->close();
}

updateSales($_POST['branch_id'], $_POST['unit_price'], $_POST['quantity_sold'], $_POST['profit'], $_POST['delivery_status'], $_POST['employee_id']);

$conn->close();
?>