<?php
require_once('DBconnect.php');
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Admin List</title>
		<link rel="stylesheet" href="bootstrap.min.css">
		<link href="main.css" rel="stylesheet"/> 
	</head>
	<body>
		<!-- following section is used for creating the menubar in the webpage -->
		<section id="header">
			<div class="row">
				<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> IMS </div>
				<div class="col-md-10" style="text-align: right">
					<a href="home.php"> Home </a>
					<a href="#" style="margin-left: 20px;"> Employee </a>
					<a href="admin.php" style="margin-left: 20px;"> Admin </a>
				</div>
			</div>
		</section>

		<!-- Admin List Section -->
		<section id= "section1">
			<div class= "title"> Admin List </div>
			<div class="container" style="background-color:rgb(157, 240, 248); padding: 20px; border-radius: 10px;">
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>ID</th>
						<th>First Name</th>
						<th>Last Name</th>
						<th>Email</th>
						<th>Address</th>
						<th>Salary</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$sql = "SELECT * FROM admin";
					$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {
						while($row = mysqli_fetch_assoc($result)) {
							echo "<tr>";
							echo "<td>" . $row['ID'] . "</td>";
							echo "<td>" . $row['first_name'] . "</td>";
							echo "<td>" . $row['last_name'] . "</td>";
							echo "<td>" . $row['email'] . "</td>";
							echo "<td>" . $row['address'] . "</td>";
							echo "<td>" . $row['salary'] . "</td>";
							echo "</tr>";
						}
					} else {
						echo "<tr><td colspan='3'>No admins found</td></tr>";
					}
					?>
				</tbody>
			</table>
		</section>

		<!----- Footer ----->
		<section id="footer">
		</section>
		<script src="jquery.js"></script>
		<script src="bootstrap.min.js"></script>
		<script src="jquery.isotope.min.js"></script>
		<script src="wow.min.js"></script>
	</body>
</html>