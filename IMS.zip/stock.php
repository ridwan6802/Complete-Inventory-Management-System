<?php
// Connect to the database
require_once('DBconnect.php');

// Query to get stock data
$sql = "SELECT * FROM stock";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock</title>
    <link href="bootstrap.min.css" rel="stylesheet"/>
    <style>
        body {
        background-image: url('stock.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .container {
            background-color: rgba(255, 128, 128, 0.8); /* Optional: to make the content more readable */
            padding: 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Stock List</h1>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Location</th>
                    <th>Maintenance</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['location'] . "</td>";
                        echo "<td>" . $row['maintenance'] . "</td>";
                        echo "<td>" . $row['time'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No stock available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>