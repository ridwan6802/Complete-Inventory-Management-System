<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Sign Up </title>
    
      <!-- core CSS -->
      <link href="bootstrap.min.css" rel="stylesheet"/>
      <link href="font-awesome.min.css" rel="stylesheet"/>
      <link href="animate.min.css" rel="stylesheet"/>
      <link href="main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> IMS </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="#"> Home </a> 
				<a href="#" style="margin-left: 20px;"> Students </a> 
				<a href="#" style="margin-left: 20px;"> Teachers  </a> 
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> New Employee </div>
		
		<form action="insert_employee.php" class="form_design" method="post" onsubmit="return validatePasswords()">
    		ID: <input type="text" name="ID"> <br/>
    		First Name: <input type="text" name="fname"> <br/> 
    		Last Name: <input type="text" name="lname"> <br/>
    		Email: <input type="text" name="email"> <br/>
    		Branch ID: <input type="text" name="branch_id"> <br/>
    		Username: <input type="text" name="username"> <br/>
    		Password: <input type="password" name="password" id="password"> <br/>
    		Confirm Password: <input type="password" name="confirm_password" id="confirm_password"> <br/>
    		<br/>
    		<input type="submit" value="Sign Up">
		</form>
	</section>

	<script>
		function validatePasswords() {
			var password = document.getElementById("password").value;
			var confirmPassword = document.getElementById("confirm_password").value;
			if (password != confirmPassword) {
				alert("Passwords do not match.");
				return false;
			}
			return true;
		}
	</script>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="jquery.isotope.min.js"></script>
    <script src="wow.min.js"></script>
  </body> 
</html>

