<?php
require_once('DBconnect.php');

if(isset($_POST['ID']) && isset($_POST['name']) && isset($_POST['cost']) && isset($_POST['quantity']) && isset($_POST['shelf_life']) && isset($_POST['stock_location'])){
    $i = $_POST['ID'];
	$n = $_POST['name'];
	$c = $_POST['cost'];
	$q = $_POST['quantity'];
    $sh = $_POST['shelf_life'];
    $st = $_POST['stock_location'];

	if (empty($i) || empty($n) || empty($c) || empty($q) || empty($sh) || empty($st)) {
        echo "All fields are required.";
        exit();
    }
	
	$sql = " INSERT INTO product VALUES('$i', '$n', '$c', '$q', '$sh', '$st') ";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);
	
	//check if this insertion is happening in the database
	if(mysqli_affected_rows($conn)){
	
		echo "Inserted Successfully";
		header("Location: admin_home.php");
	}
	else{
		echo "Insertion Failed";
		header("Location: add_product.php");
	}
	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link href="bootstrap.min.css" rel="stylesheet"/>
    <style>
        body {
            background-image: url('stock.jpg'); /* Replace with your background image path */
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 25px;
            magrin-top: 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h1 {
            text-align: center;
        }
        .form-container form {
            display: flex;
            flex-direction: column;
        }
        .form-container label, .form-container input {
            margin-bottom: 0px;
        }
        .form-container input[type="submit"] {
            align-self: center;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="form-container" style="width: 50%;">
        <h1>Add Product</h1>
        <form method="post" action="add_product.php">
            <input type="hidden" name="action" value="order">
            <label for="ID">Product ID:</label>
            <input type="number" name="ID" required><br>
            <label for="name">Product Name:</label>
            <input type="text" name="name" required><br>
            <label for="cost">Cost:</label>
            <input type="number" step="0.01" name="cost" required><br>
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" required><br>
            <label for="shelf_life">Shelf Life:</label>
            <input type="number" name="shelf_life" required><br>
            <label for="stock_location">Stock Location:</label>
            <input type="text" name="stock_location" required><br>
            <input type="submit" value="Order Product">
        </form>
        <br>

    </div>
</body>
</html>