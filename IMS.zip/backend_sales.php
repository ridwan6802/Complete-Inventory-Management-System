<?php
include 'DBconnect.php'; // Include the database connection file

// Query to fetch sales data
$sql = "SELECT branch_id, unit_price, quantity_sold, profit, delivery_status, unit_price*quantity_sold as total_amount FROM sales";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<div class='container' style='background-color:rgb(89, 232, 175); padding: 20px; border-radius: 10px;'>
        <table class='table table-bordered'>
            <thead class='thead-light'>
                <tr>
                    <th>Branch ID</th>
                    <th>Unit Price($)</th>
                    <th>Quantity Sold</th>
                    <th>Profit($)</th>
                    <th>Delivery Status</th>
                    <th>Total Amount($)</th>
                </tr>
            </thead>
            <tbody>";
    while($row = $result->fetch_assoc()) {
        $delivery_status = $row["delivery_status"] == 1 ? 'Complete' : 'Pending';
        echo "<tr>
                <td>" . $row["branch_id"]. "</td>
                <td>" . $row["unit_price"]. "</td>
                <td>" . $row["quantity_sold"]. "</td>
                <td>" . $row["profit"]. "</td>
                <td>" . $delivery_status. "</td>
                <td>" . $row["total_amount"]. "</td>
              </tr>";
    }
    echo "  </tbody>
        </table>";
} else {
    echo "<p>No results found</p>";
}
$conn->close();
?>