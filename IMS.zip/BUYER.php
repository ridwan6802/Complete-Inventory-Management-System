<?php
// filepath: /c:/xampp/htdocs/IMS/untitled-1.php
require('DBconnect.php');

// Function to add a new entry to the buys table
if(isset($_POST['customer_id']) && isset($_POST['product_id']) && isset($_POST['branch_id']) && isset($_POST['date']) && isset($_POST['quantity'])){

    $c = $_POST['customer_id'];
	$p = $_POST['product_id'];
    $b = $_POST['branch_id'];
	$d = $_POST['date'];
    $q = $_POST['quantity'];


	if (empty($c) || empty($p) || empty($b) || empty($d) || empty($q)) {
        echo "All fields are required.";
        exit();
    }
	
	$sql = " INSERT INTO buys VALUES( '$c', '$p', '$b', '$d', '$q') ";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);

    if (mysqli_affected_rows($conn)) {
        // Update product_id and quantity in branch table
        $update_sql = "UPDATE branch SET product_id = '$p', product_quantity = product_quantity - '$q' WHERE branch_id = '$b'";
        $update_result = mysqli_query($conn, $update_sql);

        if (mysqli_affected_rows($conn)) {
            header("Location: employee_home.php");
        } else {
            echo "<script>alert('Failed to update branch table!'); window.location.href = 'BUYER.php';</script>";
        }
    }
	else{
		echo "<script>alert('Something went wrong!'); window.location.href = 'BUYER.php';</script>";
	}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Buys</title>
    <style>
        body {
            background-image: url('bg.jpg'); /* Replace with your background image path */
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: rgba(0, 111, 139, 0.7);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgb(0, 0, 0);
        }
        .form-container h1 {
            text-align: center;
        }
        .form-container form {
            display: flex;
            flex-direction: column;
        }
        .form-container label, .form-container input {
            margin-bottom: 10px;
        }
        .form-container input[type="submit"] {
            align-self: center;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="form-container">
    <h1>ADD Entry</h1>
    <form method="post" action="BUYER.php">
        <label for="customer_id">Customer ID:</label>
        <input type="number" name="customer_id" required><br>
        <label for="product_id">Product ID:</label>
        <input type="number" name="product_id" required><br>
        <label for="branch_id">Branch ID:</label>
        <input type="number" name="branch_id" required><br>
        <label for="date">Date:</label>
        <input type="date" name="date" required><br>
        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" required><br>
        <input type="submit" value="Add Entry">
    </form>
    </div>
</body>
</html>