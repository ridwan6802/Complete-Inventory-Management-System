<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Sales</title>
    <style>
        body {
            background-image: url('bg.jpg'); /* Replace with your background image path */
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Times, sans-serif;
        }
        .container {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        .container h1 {
            margin-bottom: 20px;
        }
        .container label {
            display: block;
            margin-bottom: 5px;
            text-align: left;
        }
        .container input[type="number"],
        .container input[type="text"] {
            width: 100%;
            padding: 4px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .container input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Sales</h1>
        <form action="updatesales.php" method="POST">
            <label for="branch_id">Branch ID:</label>
            <input type="number" id="branch_id" name="branch_id" required><br><br>

            <label for="unit_price">Unit Price:</label>
            <input type="number" step="0.01" id="unit_price" name="unit_price" required><br><br>

            <label for="quantity_sold">Quantity Sold:</label>
            <input type="number" id="quantity_sold" name="quantity_sold" required><br><br>

            <label for="profit">Profit:</label>
            <input type="number" step="0.01" id="profit" name="profit" required><br><br>

            <label for="delivery_status">Delivery Status:</label>
            <input type="text" id="delivery_status" name="delivery_status" required><br><br>

            <label for="employee_id">Employee ID:</label>
            <input type="number" id="employee_id" name="employee_id" required><br><br>

            <input type="submit" value="Update Sale">
        </form>
    </div>
</body>
</html>