<?php
require('DBconnect.php');

// Assuming you have a session started and user ID stored in session
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: employee_signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user information from the database
$sql = "SELECT * FROM employee WHERE ID='$user_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
} else {
    echo "User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="bootstrap.min.css" rel="stylesheet"/>
    <link href="font-awesome.min.css" rel="stylesheet"/>
    <link href="animate.min.css" rel="stylesheet"/>
    <link href="main.css" rel="stylesheet"/> 

</head>
<body>
<section id="header" style="padding: 20px; background-color:rgb(40, 57, 101, 0.9); display: flex; justify-content: space-between; align-items: center;">
    <div style="font-size: 30px; color: #F2674A;">
        <a href="employee_home.php">IMS</a></div>
    <a href="employee_edit_profile.php" class="btn btn-primary">Edit Profile</a>
</section>
    
    <!-- Profile Section -->
    <section id="section1">
        <div class="title" style="margin-top: 50px;">Profile</div>
        <div class="container" style="background-color: #f8f9fa; padding: 20px; border-radius: 10px; margin-top: 50px; margin-bottom: 60px;">
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <td><?php echo $user['ID']; ?></td>
                </tr>
                <tr>
                    <th>First Name</th>
                    <td><?php echo $user['first_name']; ?></td>
                </tr>
                <tr>
                    <th>Last Name</th>
                    <td><?php echo $user['last_name']; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $user['email']; ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><?php echo $user['address']; ?></td>
                </tr>
                <tr>
                    <th>Salary</th>
                    <td><?php echo $user['salary']; ?></td>
                </tr>
                <tr>
                    <th>Branch ID</th>
                    <td><?php echo $user['branch_id']; ?></td>
                </tr>
            </table>
        </div>
    </section>

    <!----- Footer ----->
    <section id="footer"> 
    </section>
    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="jquery.isotope.min.js"></script>
    <script src="wow.min.js"></script>
    
</body>
</html>